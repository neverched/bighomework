create definer = root@localhost trigger dept_manager_delete_trigger
    after delete
    on dept_manager
    for each row
BEGIN
  DELETE FROM dept_manager_title
  WHERE emp_no = OLD.emp_no AND from_date = OLD.from_date AND to_date = OLD.to_date;
END;

